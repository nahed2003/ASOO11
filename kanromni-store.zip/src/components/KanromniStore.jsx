
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, Phone, ShoppingBag, UserPlus } from "lucide-react";

export default function KanromniStore() {
  const [language, setLanguage] = useState("en");

  const texts = {
    en: {
      welcome: "Welcome to Kanromni Clothing Store",
      login: "Login",
      signup: "Sign Up",
      products: "Products",
      gallery: "Gallery",
      contact: "Contact Us",
      name: "Name",
      email: "Email",
      message: "Message",
      send: "Send Message"
    },
    ar: {
      welcome: "مرحبًا بكم في متجر كنرومني للملابس",
      login: "تسجيل الدخول",
      signup: "إنشاء حساب",
      products: "المنتجات",
      gallery: "معرض الصور",
      contact: "تواصل معنا",
      name: "الاسم",
      email: "البريد الإلكتروني",
      message: "رسالة",
      send: "إرسال الرسالة"
    }
  };

  const t = texts[language];

  return (
    <div className="p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">
          {t.welcome} - <span className="text-blue-600">Aso</span>
        </h1>
        <div>
          <Button variant="outline" onClick={() => setLanguage("en")}>EN</Button>
          <Button variant="outline" onClick={() => setLanguage("ar")} className="ml-2">AR</Button>
        </div>
      </div>

      <Tabs defaultValue="login" className="w-full">
        <TabsList>
          <TabsTrigger value="login"><UserPlus className="mr-2 w-4 h-4" /> {t.login}</TabsTrigger>
          <TabsTrigger value="signup"><UserPlus className="mr-2 w-4 h-4" /> {t.signup}</TabsTrigger>
          <TabsTrigger value="products"><ShoppingBag className="mr-2 w-4 h-4" /> {t.products}</TabsTrigger>
          <TabsTrigger value="gallery">🖼 {t.gallery}</TabsTrigger>
          <TabsTrigger value="contact"><Mail className="mr-2 w-4 h-4" /> {t.contact}</TabsTrigger>
        </TabsList>

        <TabsContent value="login">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <Input placeholder={t.email} />
              <Input placeholder="Password" type="password" />
              <Button className="w-full">{t.login}</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="signup">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <Input placeholder={t.name} />
              <Input placeholder={t.email} />
              <Input placeholder="Password" type="password" />
              <Button className="w-full">{t.signup}</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="hover:shadow-lg">
                <CardContent className="p-4">
                  <img src={`https://via.placeholder.com/300x200?text=Product+${i}`} alt={`Product ${i}`} className="mb-2 rounded" />
                  <p className="font-bold">Product {i}</p>
                  <p>$99.00</p>
                  <Button className="mt-2 w-full">Buy</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="gallery">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[1, 2, 3, 4].map((i) => (
              <img key={i} src={`https://via.placeholder.com/200x200?text=Image+${i}`} alt={`Gallery ${i}`} className="rounded" />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contact">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <Input placeholder={t.name} />
              <Input placeholder={t.email} />
              <Input placeholder={t.message} />
              <Button className="w-full">{t.send}</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
