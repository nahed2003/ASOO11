
import KanromniStore from '../src/components/KanromniStore'

export default function Home() {
  return <KanromniStore />
}
